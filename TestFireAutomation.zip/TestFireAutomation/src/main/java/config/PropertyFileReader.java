package config;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyFileReader {
	static Properties prop = new Properties();

	static {
		try {
			String path = System.getProperty("user.dir") + "confif.properties";
			FileInputStream fis = new FileInputStream(path);
			prop.load(fis);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String get(String key) {
		return prop.getProperty(key);
	}
}