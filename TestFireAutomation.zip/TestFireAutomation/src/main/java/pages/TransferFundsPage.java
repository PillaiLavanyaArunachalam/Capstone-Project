package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class TransferFundsPage {
    WebDriver driver;

    @FindBy(linkText = "Transfer Funds") WebElement transferFundsLink;
	@FindBy(id = "fromAccount") WebElement fromAccountDropdown;
    @FindBy(id = "toAccount") WebElement toAccountDropdown;
    @FindBy(id = "transferAmount") WebElement amountField;
    @FindBy(id = "transfer") WebElement transferButton;
    @FindBy(xpath = "//*[@id=\"_ctl0__ctl0_Content_Main_postResp\"]/span") WebElement successMessage;

    public TransferFundsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void goToTransferFunds() {
        transferFundsLink.click();
    }

    public void fillTransferDetails(String fromAccount, String toAccount, String amount) {
        Select fromDropdown = new Select(fromAccountDropdown);
        Select toDropdown = new Select(toAccountDropdown);

        fromDropdown.selectByVisibleText(fromAccount); // Example: "800000 Checking"
        toDropdown.selectByVisibleText(toAccount);     // Example: "800003 Savings"

        amountField.clear();
        amountField.sendKeys(amount);
    }

    public void submitTransfer() {
        transferButton.click();
    }

    public String getSuccessMessage() {
        return successMessage.getText();
    }
}
