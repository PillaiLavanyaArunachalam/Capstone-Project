package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AccountPage {
	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"listAccounts\"]")
	WebElement accountDropdown;
	@FindBy(id = "btnGetAccount")
	WebElement goBtn;
	@FindBy(xpath = "//td[normalize-space(text())='Available balance']/following-sibling::td")
	WebElement balance;

	public AccountPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void viewAccountDetails() {
		accountDropdown.sendKeys("800002 Savings");
		goBtn.click();
	}

	public String getAvailableBalance() {
		return balance.getText();
	}
}


















///html/body/table[2]/tbody/tr/td[2]/div/table/tbody/tr[1]/td/table/tbody/tr[4]/td[2]
/*
 * @FindBy(
 * xpath="//table//td[contains(text(),'Available Balance')]/following-sibling::td"
 * ) WebElement balance;
 */