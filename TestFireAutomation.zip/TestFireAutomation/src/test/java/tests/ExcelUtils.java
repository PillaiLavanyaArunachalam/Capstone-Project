package tests;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.*;

import config.PropertyFileReader;

import java.io.*;

public class ExcelUtils {
	private static Workbook workbook;
	private static Sheet sheet;

	public static void openExcel(String filePath, String sheetName) throws IOException {
		FileInputStream fis = new FileInputStream(filePath);
		workbook = WorkbookFactory.create(fis);
		sheet = workbook.getSheet(sheetName);
	}

	public static String getCellData(int rowNum, int colNum) {
		Row row = sheet.getRow(rowNum);
		Cell cell = row.getCell(colNum);
		return cell.toString();
	}

	public static int getRowCount() {
		return sheet.getPhysicalNumberOfRows();
	}

	public static Object[][] getTestData(String filePath, String sheetName) throws IOException {
		openExcel(filePath, sheetName);
		int rows = getRowCount();
		int cols = sheet.getRow(0).getLastCellNum();

		Object[][] data = new Object[rows - 1][cols];

		for (int i = 1; i < rows; i++) { // Start from row 1 (skip header)
			for (int j = 0; j < cols; j++) {
				data[i - 1][j] = getCellData(i, j);
			}
		}

		workbook.close();
		return data;
	}

}