package tests;

import java.io.IOException;
import org.testng.annotations.Test;

import pages.LoginPage;

public class LoginTest extends BaseTest {

	@Test
	public void testLogin() throws IOException {
		String filePath = "C:\\Users\\edrin\\OneDrive\\Documents\\Testdata.xlsx";
		String sheetName = "Sheet1";
		ExcelUtils.openExcel(filePath, sheetName);
		String username = ExcelUtils.getCellData(1, 0);
		String password = ExcelUtils.getCellData(1, 1);

		LoginPage loginPage = new LoginPage(driver);
		loginPage.login(username, password);

		test.info("Verify that login is successful");

	}
}