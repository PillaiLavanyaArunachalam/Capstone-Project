package tests;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import com.aventstack.extentreports.ExtentTest;
import org.testng.annotations.Test;
import org.testng.Assert;
import pages.LoginPage;
import pages.TransferFundsPage;

public class FundTransferTest extends BaseTest {

	@DataProvider(name = "transferData")
	public Object[][] getTransferData() throws Exception {
		String filePath = "C:\\Users\\edrin\\OneDrive\\Documents\\Testdata.xlsx";
		String sheetName = "Sheet2";
		return ExcelUtils.getTestData(filePath, sheetName);
	}

	@Test(dataProvider = "transferData")
	public void verifyFundTransfer(String fromAccount, String toAccount, String amount) throws IOException {
		new LoginPage(driver).login("jsmith", "demo1234");

		TransferFundsPage tfp = new TransferFundsPage(driver);
		tfp.goToTransferFunds();
		tfp.fillTransferDetails(fromAccount, toAccount, amount);
		tfp.submitTransfer();

		String message = tfp.getSuccessMessage();
		Assert.assertTrue(message.contains("was successfully transferred"));
		test.info("Verified fund transfer: " + amount + " from " + fromAccount + " to " + toAccount);
	}
}

//package tests;
//
//import java.io.IOException;
//
//import org.testng.Assert;
//import org.testng.annotations.Test;
//
//import com.aventstack.extentreports.ExtentTest;
//
//import pages.LoginPage;
//import pages.TransferFundsPage;
//
//public class FundTransferTest extends BaseTest {
//
//	public Object[][] getTransferData() throws Exception {
//        String filePath = "C:\\\\Users\\\\edrin\\\\OneDrive\\\\Documents\\\\Testdata.xlsx";
//        String sheetName = "Sheet2";
//        return ExcelUtils.getTestData(filePath, sheetName);
//    }
//	
//    @Test 
//    public void verifyFundTransfer(String fromAccount, String toAccount, String amount) throws IOException {
//        // Optionally login first if needed (hardcoded or from Excel)
//         new LoginPage(driver).login("jsmith", "demo1234");
////      public void verifyFundTransfer()
//    	
//        TransferFundsPage tfp = new TransferFundsPage(driver);
//        tfp.goToTransferFunds();
//        tfp.fillTransferDetails(fromAccount, toAccount, amount);
//        tfp.submitTransfer();
//
//        String message = tfp.getSuccessMessage();
//        Assert.assertTrue(message.contains("was successfully transferred"));
//        test.info("Verified fund transfer: " + amount + " from " + fromAccount + " to " + toAccount);
//        
//        
//    }
//}
