package tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import pages.AccountPage;
import pages.LoginPage;

public class AccountTest extends BaseTest {

	@Test
	public void verifyBalanceNotEmpty() throws IOException {
		new LoginPage(driver).login("jsmith", "demo1234");
		AccountPage ap = new AccountPage(driver);
		ap.viewAccountDetails();
		String balance = ap.getAvailableBalance();
		Assert.assertFalse(balance.isEmpty(), "Available Balance should not be empty");
		test.info("Verify that available balance is not empty");
	}
}