
package tests;

import java.lang.reflect.Method;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentTest;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ExtentReportManager;

public class BaseTest {
	protected WebDriver driver;
	protected ExtentTest test;
	String baseUrl = "https://demo.testfire.net";

	@Parameters("browser")
	@BeforeMethod
	public void setUp(@Optional("chrome") String browser, Method method) throws InterruptedException {
		test = ExtentReportManager.createTest(method.getName());

		switch (browser.toLowerCase()) {

		case "firefox":
			WebDriverManager.firefoxdriver().setup(); // Using WebDriverManager for Firefox
			driver = new FirefoxDriver();
			break;

		case "chrome":
		default:
			WebDriverManager.chromedriver().setup(); // Using WebDriverManager for Chrome
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--guest"); // Optional: use "--incognito" if preferred
			driver = new ChromeDriver(options);
			break;
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(baseUrl);
	}

	@AfterMethod
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
		ExtentReportManager.flushReport();
	}
}





/*
 * package tests;
 * 
 * 
 * import java.lang.reflect.Method; import java.time.Duration;
 * 
 * import org.openqa.selenium.WebDriver; import
 * org.openqa.selenium.chrome.ChromeDriver; import
 * org.openqa.selenium.chrome.ChromeOptions; import
 * org.openqa.selenium.firefox.FirefoxDriver; import
 * org.testng.annotations.AfterMethod; import
 * org.testng.annotations.BeforeMethod; import org.testng.annotations.Optional;
 * import org.testng.annotations.Parameters;
 * 
 * import com.aventstack.extentreports.ExtentTest;
 * 
 * import io.github.bonigarcia.wdm.WebDriverManager; import
 * utils.ExtentReportManager;
 * 
 * //@Listeners(utils.CustomReporter.class) public class BaseTest { protected
 * WebDriver driver; protected ExtentTest test; String
 * baseUrl="https://demo.testfire.net";
 * 
 * @Parameters("browser")
 * 
 * @BeforeMethod public void setUp(@Optional("chrome") String browser, Method
 * method) throws InterruptedException { test =
 * ExtentReportManager.createTest(method.getName());
 * 
 * switch (browser.toLowerCase()) {
 * 
 * case "firefox": WebDriverManager.firefoxdriver().setup(); WebDriver driver =
 * new FirefoxDriver();
 * 
 * // System.setProperty("webdriver.gecko.driver",
 * "C:\\Tools\\geckodriver.exe"); //driver = new FirefoxDriver(); // driver =
 * new FirefoxDriver(capabilities); //driver = new FirefoxDriver(); break;
 * 
 * default: System.setProperty("webdriver.chrome.driver",
 * "C:\\Users\\edrin\\OneDrive\\Documents\\drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe"
 * ); ChromeOptions options = new ChromeOptions();
 * options.addArguments("--guest"); // or use "--incognito" driver = new
 * ChromeDriver(options); // driver = new ChromeDriver(); break; }
 * 
 * driver.manage().window().maximize();
 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
 * driver.get(baseUrl); }
 * 
 * @AfterMethod public void tearDown() { if (driver != null) { driver.quit(); }
 * ExtentReportManager.flushReport(); } }
 */