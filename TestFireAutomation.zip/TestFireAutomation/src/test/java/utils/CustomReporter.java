/*
 * package utils;
 * 
 * import org.testng.*;
 * 
 * public class CustomReporter implements ITestListener { public void
 * onTestStart(ITestResult result) { System.out.println("🔄 Starting: " +
 * result.getName()); }
 * 
 * public void onTestSuccess(ITestResult result) {
 * System.out.println("✅ PASSED: " + result.getName()); }
 * 
 * public void onTestFailure(ITestResult result) {
 * System.out.println("❌ FAILED: " + result.getName());
 * System.out.println("Reason: " + result.getThrowable()); } }
 */