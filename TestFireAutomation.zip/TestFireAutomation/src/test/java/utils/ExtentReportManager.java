package utils;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportManager {

	private static ExtentReports extent;
	private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();

	// Create or return singleton ExtentReports instance
	public static ExtentReports getInstance() {
		if (extent == null) {
			ExtentSparkReporter reporter = new ExtentSparkReporter(
					"C:\\Users\\edrin\\Downloads\\SeleniumJavaFrameworkFull\\test-output\\extentReport.html");
			extent = new ExtentReports();
			extent.attachReporter(reporter);

		}
		return extent;
	}

	// Create a test log entry for a specific test
	public static ExtentTest createTest(String name) {
		ExtentTest extentTest = getInstance().createTest(name);
		test.set(extentTest);
		return extentTest;
	}

	// Get the current thread’s test logger
	public static ExtentTest getTest() {
		return test.get();
	}

	// Flush the report once all tests are done
	public static void flushReport() {
		if (extent != null) {
			extent.flush();
		}
	}
}
